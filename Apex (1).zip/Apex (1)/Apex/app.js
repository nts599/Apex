
// Updated app.js (Fully corrected)
const API_URL = "http://localhost:5000/api";

document.addEventListener("DOMContentLoaded", () => {
  initToggles();
  initProfileModal();
  loadProfileFromDB();
  initBlockerButtons();
  initSessionButtons();
  loadAppsForBlocker();
  loadSessionsForReports();
});

// 1. TOGGLES & Dark Mode
function initToggles() {
  document.querySelectorAll(".toggle").forEach((toggle) => {
    toggle.addEventListener("click", () => toggle.classList.toggle("on"));
  });

  const darkToggle = document.getElementById("darkModeToggle");
  if (darkToggle) {
    darkToggle.addEventListener("click", () => {
      document.querySelector(".phone").classList.toggle("dark-mode");
    });
  }
}

// 2. PROFILE MODAL
async function loadProfileFromDB() {
  try {
    const res = await fetch(`${API_URL}/user`);
    if (!res.ok) throw new Error('Failed to fetch profile');
    const user = await res.json();
    document.getElementById("profileName").textContent = user.name;
    document.getElementById("profileEmail").textContent = user.email;
    document.getElementById("profileAvatar").src = user.avatar_url;
  } catch (err) {
    console.error("Profile load error:", err);
  }
}

function initProfileModal() {
  const trigger = document.getElementById("editProfileTrigger");
  const modal = document.getElementById("profileModal");
  if (!trigger || !modal) return;

  const cancelBtn = document.getElementById("modalCancel");
  const saveBtn = document.getElementById("modalSave");
  const avatarUploadTrigger = document.getElementById("avatarUploadTrigger");
  const avatarFileInput = document.getElementById("avatarFileInput");
  const modalAvatarPreview = document.getElementById("modalAvatarPreview");
  const nameInput = document.getElementById("nameInput");
  const emailInput = document.getElementById("emailInput");

  trigger.addEventListener("click", async () => {
    const res = await fetch(`${API_URL}/user`);
    const user = await res.json();
    nameInput.value = user.name;
    emailInput.value = user.email;
    modalAvatarPreview.src = user.avatar_url;
    modal.classList.add("visible");
  });

  cancelBtn.addEventListener("click", () => modal.classList.remove("visible"));
  modal.addEventListener("click", (e) => {
    if (e.target === modal) modal.classList.remove("visible");
  });

  avatarUploadTrigger.addEventListener("click", () => avatarFileInput.click());
  avatarFileInput.addEventListener("change", () => {
    const file = avatarFileInput.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => { modalAvatarPreview.src = e.target.result; };
    reader.readAsDataURL(file);
  });

  saveBtn.addEventListener("click", async () => {
    const name = nameInput.value.trim() || "Alex Sterling";
    const email = emailInput.value.trim() || "alex@example.com";
    const avatarSrc = modalAvatarPreview.src;

    try {
      const res = await fetch(`${API_URL}/user`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, avatar_url: avatarSrc })
      });
      if (!res.ok) throw new Error('Failed to save');
      await loadProfileFromDB();
      modal.classList.remove("visible");
      showToast("Profile updated successfully!");
    } catch (err) {
      showToast("Error: " + err.message);
    }
  });
}

// 3. BLOCKER PAGE
async function loadAppsForBlocker() {
  const container = document.getElementById("app-list-container");
  if (!container) return;

  try {
    const res = await fetch(`${API_URL}/apps`);
    if (!res.ok) throw new Error('Failed to load apps');
    const apps = await res.json();
    container.innerHTML = "";

    apps.forEach(app => {
      const row = document.createElement('div');
      row.className = 'app-row';
      row.innerHTML = `
        <div class="row-left">
          <img class="app-icon-img" src="${app.icon_url}" alt="${app.app_name}">
          <div>
            <h4>${app.app_name}</h4>
            <p>Today: ${app.daily_usage_minutes}m usage</p>
          </div>
        </div>
        <button class="toggle ${app.is_blocked ? 'on' : ''}" data-id="${app.id}"></button>
      `;
      container.appendChild(row);
    });

    document.querySelectorAll("#app-list-container .toggle").forEach(async (btn) => {
      btn.addEventListener("click", async (e) => {
        e.stopPropagation();
        const id = btn.dataset.id;
        await fetch(`${API_URL}/apps/${id}`, { method: 'PUT' });
        btn.classList.toggle("on");
      });
    });

    document.querySelector(".pill-btn")?.addEventListener("click", async () => {
      document.querySelectorAll("#app-list-container .toggle").forEach(async (btn) => {
        await fetch(`${API_URL}/apps/${btn.dataset.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ is_blocked: true })
        });
        btn.classList.add('on');
      });
      showToast("All apps blocked!");
    });

  } catch (err) {
    showToast("Database Error: " + err.message);
  }
}

// 4. REPORTS
async function loadSessionsForReports() {
  const title = document.querySelector(".screen-title");
  if (!title || title.textContent.trim() !== "Weekly Insights") return;

  try {
    const res = await fetch(`${API_URL}/sessions`);
    const sessions = await res.json();
    const totalTime = sessions.reduce((sum, s) => sum + s.duration_minutes, 0);
    const totalHoursEl = document.querySelector(".value-big");
    if (totalHoursEl) totalHoursEl.textContent = (totalTime / 60).toFixed(1) + "h";
  } catch (err) {
    console.error("Report load error:", err);
  }
}

// 5. SESSION BUTTONS (With fixed brackets!)
function initSessionButtons() {
  document.querySelector(".select-field")?.addEventListener("click", () => alert("Select Subject clicked"));

  const uploadBox = document.querySelector(".upload-box");
  if (uploadBox) {
    const fileInput = document.createElement("input");
    fileInput.type = "file";
    fileInput.accept = ".pdf,.doc,.docx,image/*";
    fileInput.style.display = "none";
    document.body.appendChild(fileInput);
    uploadBox.addEventListener("click", () => fileInput.click());
    fileInput.addEventListener("change", () => {
      if (fileInput.files.length > 0) {
        const fileNameEl = document.getElementById("fileName");
        if (fileNameEl) {
          fileNameEl.textContent = "Uploaded: " + fileInput.files[0].name;
          fileNameEl.style.color = "var(--green)";
        }
      }
    });
  }

  document.querySelector(".btn-green")?.addEventListener("click", () => showToast("Session started!"));
} // <--- THIS IS THE FIXED CLOSING BRACKET

// 6. TOAST SYSTEM
function showToast(message) {
  const toast = document.getElementById("toast");
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add("visible");
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(() => toast.classList.remove("visible"), 2000);
}

// 7. INIT BLOCKER BUTTONS
function initBlockerButtons() {
  const tabs = document.querySelectorAll(".tabs .tab");
  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      tabs.forEach((item) => item.classList.remove("active"));
      tab.classList.add("active");
    });
  });
}